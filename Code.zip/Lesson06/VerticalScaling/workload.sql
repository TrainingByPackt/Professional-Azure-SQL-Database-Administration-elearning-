-- Code is reviewed and is in working condition

SELECT a.*
	FROM 
	sys.objects a, 
	sys.objects b,
	sys.objects c,
	sys.objects d,
	sys.objects e,
	sys.objects f,
	sys.objects g,
	sys.objects h